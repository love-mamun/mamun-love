-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 25, 2023 at 11:56 AM
-- Server version: 10.3.39-MariaDB-cll-lve
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `winmoney_firewin`
--

-- --------------------------------------------------------

--
-- Table structure for table `abbetrec`
--

CREATE TABLE `abbetrec` (
  `id` int(11) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `num` varchar(20) NOT NULL,
  `clo` varchar(21) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `abbetrec`
--

INSERT INTO `abbetrec` (`id`, `period`, `ans`, `num`, `clo`, `time`) VALUES
(1, 45635876097, 'B', '41699', '82', '2023-10-25 11:47:26'),
(2, 45635876098, 'T', '41204', '5194287', '2023-10-25 11:48:27'),
(3, 45635876099, 'B', '40137', '29645138', '2023-10-25 11:49:26'),
(4, 45635876100, 'A', '42657', '75193', '2023-10-25 11:50:01'),
(5, 45635876101, 'B', '47049', '162978', '2023-10-25 11:51:27'),
(6, 45635876102, 'A', '47747', '1675349', '2023-10-25 11:52:27'),
(7, 45635876103, 'B', '44131', '17', '2023-10-25 11:53:27'),
(8, 45635876104, 'B', '49396', '83', '2023-10-25 11:54:26'),
(9, 45635876105, 'B', '46776', '25486197', '2023-10-25 11:55:02');

-- --------------------------------------------------------

--
-- Table structure for table `abbetting`
--

CREATE TABLE `abbetting` (
  `id` int(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `res` varchar(255) NOT NULL DEFAULT 'wait',
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `number` varchar(255) NOT NULL DEFAULT 'wait'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `abperiod`
--

CREATE TABLE `abperiod` (
  `id` int(11) NOT NULL DEFAULT 1,
  `period` bigint(20) NOT NULL,
  `num` int(11) DEFAULT NULL,
  `nxt` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `abperiod`
--

INSERT INTO `abperiod` (`id`, `period`, `num`, `nxt`) VALUES
(1, 45635876106, 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(211) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `apply`
--

CREATE TABLE `apply` (
  `id` int(11) NOT NULL,
  `username` varchar(211) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` varchar(211) NOT NULL DEFAULT 'Applying',
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beconebet`
--

CREATE TABLE `beconebet` (
  `TIME` datetime NOT NULL DEFAULT current_timestamp(),
  `id` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beconebetrec`
--

CREATE TABLE `beconebetrec` (
  `id` int(11) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `num` varchar(20) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `beconebetrec`
--

INSERT INTO `beconebetrec` (`id`, `period`, `ans`, `num`, `time`) VALUES
(1, 20231026685, '74', '43974', '2023-10-25 11:47:26'),
(2, 20231026686, '15', '45415', '2023-10-25 11:48:27'),
(3, 20231026687, '77', '46677', '2023-10-25 11:49:26'),
(4, 20231026688, '42', '40442', '2023-10-25 11:50:26'),
(5, 20231026689, '16', '48016', '2023-10-25 11:51:27'),
(6, 20231026690, '83', '46783', '2023-10-25 11:52:32'),
(7, 20231026691, '51', '48651', '2023-10-25 11:53:27'),
(8, 20231026692, '13', '43313', '2023-10-25 11:54:27'),
(9, 20231026693, '57', '43457', '2023-10-25 11:55:02');

-- --------------------------------------------------------

--
-- Table structure for table `beconebetting`
--

CREATE TABLE `beconebetting` (
  `id` int(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` int(11) NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `res` varchar(255) NOT NULL DEFAULT 'wait',
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `price` varchar(211) NOT NULL DEFAULT 'wait',
  `number` varchar(255) NOT NULL DEFAULT 'wait'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `beconeperiod`
--

CREATE TABLE `beconeperiod` (
  `id` int(11) NOT NULL DEFAULT 1,
  `period` bigint(20) NOT NULL,
  `nxt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `beconeperiod`
--

INSERT INTO `beconeperiod` (`id`, `period`, `nxt`) VALUES
(1, 20231026694, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bet`
--

CREATE TABLE `bet` (
  `TIME` datetime NOT NULL DEFAULT current_timestamp(),
  `id` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bet`
--

INSERT INTO `bet` (`TIME`, `id`) VALUES
('2023-10-25 11:55:32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `betrec`
--

CREATE TABLE `betrec` (
  `id` int(11) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `num` varchar(20) NOT NULL,
  `clo` tinytext NOT NULL,
  `res1` varchar(211) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `betrec`
--

INSERT INTO `betrec` (`id`, `period`, `ans`, `num`, `clo`, `res1`, `time`) VALUES
(1, 20231027855, '9', '41219', 'green', '', '2023-10-25 11:47:26'),
(2, 20231027856, '3', '45233', 'green', '', '2023-10-25 11:47:56'),
(3, 20231027857, '5', '49475', 'green', 'violet', '2023-10-25 11:48:27'),
(4, 20231027858, '4', '49434', 'red', '', '2023-10-25 11:48:57'),
(5, 20231027859, '3', '46073', 'green', '', '2023-10-25 11:49:26'),
(6, 20231027860, '9', '41159', 'green', '', '2023-10-25 11:49:56'),
(7, 20231027861, '9', '41629', 'green', '', '2023-10-25 11:50:01'),
(8, 20231027862, '8', '47178', 'red', '', '2023-10-25 11:50:31'),
(9, 20231027863, '0', '42040', 'red', 'violet', '2023-10-25 11:51:27'),
(10, 20231027864, '5', '46625', 'green', 'violet', '2023-10-25 11:51:57'),
(11, 20231027865, '4', '47874', 'red', '', '2023-10-25 11:52:27'),
(12, 20231027866, '5', '49315', 'green', 'violet', '2023-10-25 11:52:57'),
(13, 20231027867, '7', '44337', 'green', '', '2023-10-25 11:53:27'),
(14, 20231027868, '8', '41668', 'red', '', '2023-10-25 11:54:02'),
(15, 20231027869, '5', '41085', 'green', 'violet', '2023-10-25 11:54:26'),
(16, 20231027870, '6', '41276', 'red', '', '2023-10-25 11:54:56'),
(17, 20231027871, '2', '44582', 'red', '', '2023-10-25 11:55:02'),
(18, 20231027872, '2', '49152', 'red', '', '2023-10-25 11:55:32');

-- --------------------------------------------------------

--
-- Table structure for table `betting`
--

CREATE TABLE `betting` (
  `id` int(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `res` varchar(255) NOT NULL DEFAULT 'wait',
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `price` varchar(211) NOT NULL DEFAULT 'wait',
  `number` varchar(255) NOT NULL DEFAULT 'wait',
  `color` text NOT NULL,
  `am` varchar(211) NOT NULL DEFAULT 'wait',
  `color2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `betting`
--

INSERT INTO `betting` (`id`, `username`, `period`, `ans`, `amount`, `status`, `res`, `time`, `price`, `number`, `color`, `am`, `color2`) VALUES
(1, '8355965199', 20231027864, 'red', 10, 'sucessful', 'fail', '2023-10-25 11:51:52', '46625', '5', 'green', 'wait', 'violet'),
(2, '8355965199', 20231027864, 'green', 10, 'sucessful', 'success', '2023-10-25 11:51:54', '46625', '5', 'green', 'wait', 'violet'),
(3, '1234567890', 20231027865, 'violet', 10, 'sucessful', 'fail', '2023-10-25 11:52:03', '47874', '4', 'red', 'wait', ''),
(4, '1234567890', 20231027865, 'green', 10, 'sucessful', 'fail', '2023-10-25 11:52:05', '47874', '4', 'red', 'wait', ''),
(5, '8355965199', 20231027867, 'red', 10, 'sucessful', 'fail', '2023-10-25 11:53:05', '44337', '7', 'green', 'wait', '');

-- --------------------------------------------------------

--
-- Table structure for table `bonus`
--

CREATE TABLE `bonus` (
  `id` int(211) NOT NULL,
  `giver` bigint(211) NOT NULL,
  `usercode` varchar(255) NOT NULL,
  `amount` float NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `level` int(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bonus`
--

INSERT INTO `bonus` (`id`, `giver`, `usercode`, `amount`, `created_at`, `level`) VALUES
(1, 8355965199, 'HO6GRZ', 0.06, '2023-10-25 06:21:57', 1),
(2, 8355965199, 'HO6GRZ', 0.06, '2023-10-25 06:21:57', 1),
(3, 8355965199, 'HO6GRZ', 0.06, '2023-10-25 06:23:27', 1),
(4, 8355965199, 'HO6GRZ', 150, '2023-10-25 06:25:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `crashbetrecord`
--

CREATE TABLE `crashbetrecord` (
  `id` int(11) NOT NULL,
  `username` varchar(211) NOT NULL,
  `amount` int(11) NOT NULL,
  `status` varchar(211) NOT NULL DEFAULT 'pending',
  `winpoint` varchar(211) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `crashgamerecord`
--

CREATE TABLE `crashgamerecord` (
  `id` int(11) NOT NULL,
  `crashpoint` varchar(211) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emredbet`
--

CREATE TABLE `emredbet` (
  `TIME` datetime NOT NULL DEFAULT current_timestamp(),
  `id` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emredbetrec`
--

CREATE TABLE `emredbetrec` (
  `id` int(11) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `num` varchar(20) NOT NULL,
  `clo` tinytext NOT NULL,
  `res1` varchar(211) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emredbetrec`
--

INSERT INTO `emredbetrec` (`id`, `period`, `ans`, `num`, `clo`, `res1`, `time`) VALUES
(1, 20231025938, '9', '49799', 'green', '', '2023-10-25 11:48:27'),
(2, 20231025939, '9', '49659', 'green', '', '2023-10-25 11:51:27'),
(3, 20231025940, '5', '48715', 'green', 'violet', '2023-10-25 11:54:27');

-- --------------------------------------------------------

--
-- Table structure for table `emredbetting`
--

CREATE TABLE `emredbetting` (
  `id` int(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `res` varchar(255) NOT NULL DEFAULT 'wait',
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `price` varchar(211) NOT NULL DEFAULT 'wait',
  `number` varchar(255) NOT NULL DEFAULT 'wait',
  `color` text NOT NULL,
  `am` varchar(211) NOT NULL DEFAULT 'wait',
  `color2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emredperiod`
--

CREATE TABLE `emredperiod` (
  `id` int(11) NOT NULL DEFAULT 1,
  `period` bigint(20) NOT NULL,
  `nxt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `emredperiod`
--

INSERT INTO `emredperiod` (`id`, `period`, `nxt`) VALUES
(1, 20231025941, 11);

-- --------------------------------------------------------

--
-- Table structure for table `gift`
--

CREATE TABLE `gift` (
  `id` int(11) NOT NULL,
  `amount` int(211) NOT NULL,
  `share` int(211) NOT NULL,
  `code` varchar(211) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `giftrec`
--

CREATE TABLE `giftrec` (
  `id` int(11) NOT NULL,
  `code` varchar(211) NOT NULL,
  `username` varchar(211) NOT NULL,
  `amount` int(211) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `help`
--

CREATE TABLE `help` (
  `id` int(11) NOT NULL,
  `username` varchar(211) NOT NULL,
  `outid` int(211) NOT NULL,
  `whatsapp` varchar(211) NOT NULL,
  `des` longtext NOT NULL,
  `status` varchar(211) NOT NULL DEFAULT 'wait',
  `created` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `id` int(211) NOT NULL,
  `notice` varchar(255) NOT NULL DEFAULT 'Invite members to recharge 300 rupees to get bonus 100 rupees. About Recharge and withdrawal,contact customer care',
  `upi` varchar(211) DEFAULT NULL,
  `upi1` varchar(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`id`, `notice`, `upi`, `upi1`) VALUES
(1, 'Invite members to recharge 300 rupees to get bonus 100 rupees. About Recharge and withdrawal,contact customer care', '8355965199@upi', '');

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `id` int(11) NOT NULL,
  `api` varchar(412) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `otp`
--

INSERT INTO `otp` (`id`, `api`, `status`) VALUES
(1, 'Q7AGzfecKjR5oyMNzt3PrM5KVM87j16DGiOPPdP3OKi4YcLgSQg6FzoiOPVS', 0);

-- --------------------------------------------------------

--
-- Table structure for table `period`
--

CREATE TABLE `period` (
  `id` int(11) NOT NULL DEFAULT 1,
  `period` bigint(20) NOT NULL,
  `nxt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `period`
--

INSERT INTO `period` (`id`, `period`, `nxt`) VALUES
(1, 20231027873, 11);

-- --------------------------------------------------------

--
-- Table structure for table `recharge`
--

CREATE TABLE `recharge` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `recharge` double NOT NULL,
  `status` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `upi` varchar(211) NOT NULL,
  `utr` varchar(255) NOT NULL,
  `rand` varchar(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recharge`
--

INSERT INTO `recharge` (`id`, `username`, `recharge`, `status`, `created_at`, `upi`, `utr`, `rand`) VALUES
(1, '8355965199', 500, 'Success', '2023-10-25 11:53:28', '8355965199@upi', '123456789000', 'MGEK588A291601350174Z098YX');

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `withdraw` double NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Applying',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `rand` varchar(211) NOT NULL,
  `upi` varchar(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `saprebet`
--

CREATE TABLE `saprebet` (
  `TIME` datetime NOT NULL DEFAULT current_timestamp(),
  `id` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `saprebetrec`
--

CREATE TABLE `saprebetrec` (
  `id` int(11) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `num` varchar(20) NOT NULL,
  `clo` tinytext NOT NULL,
  `res1` varchar(211) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saprebetrec`
--

INSERT INTO `saprebetrec` (`id`, `period`, `ans`, `num`, `clo`, `res1`, `time`) VALUES
(1, 1181, '7', '42697', 'green', '', '2023-10-25 11:48:27'),
(2, 1182, '5', '43725', 'green', 'violet', '2023-10-25 11:49:26'),
(3, 1183, '5', '46535', 'green', 'violet', '2023-10-25 11:50:26'),
(4, 1184, '8', '47828', 'red', '', '2023-10-25 11:51:27'),
(5, 1185, '7', '40067', 'green', '', '2023-10-25 11:52:32'),
(6, 1186, '7', '49007', 'green', '', '2023-10-25 11:53:27'),
(7, 1187, '0', '46450', 'red', 'violet', '2023-10-25 11:54:26'),
(8, 1188, '8', '47668', 'red', '', '2023-10-25 11:55:02');

-- --------------------------------------------------------

--
-- Table structure for table `saprebetting`
--

CREATE TABLE `saprebetting` (
  `id` int(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `res` varchar(255) NOT NULL DEFAULT 'wait',
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `price` varchar(211) NOT NULL DEFAULT 'wait',
  `number` varchar(255) NOT NULL DEFAULT 'wait',
  `color` text NOT NULL,
  `am` varchar(211) NOT NULL DEFAULT 'wait',
  `color2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sapreperiod`
--

CREATE TABLE `sapreperiod` (
  `id` int(11) NOT NULL DEFAULT 1,
  `period` bigint(20) NOT NULL,
  `nxt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sapreperiod`
--

INSERT INTO `sapreperiod` (`id`, `period`, `nxt`) VALUES
(1, 1189, 11);

-- --------------------------------------------------------

--
-- Table structure for table `signin`
--

CREATE TABLE `signin` (
  `id` int(211) NOT NULL,
  `username` varchar(211) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `amount` int(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `refcode` varchar(255) NOT NULL,
  `usercode` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `balance` double NOT NULL DEFAULT 20,
  `account` bigint(255) NOT NULL DEFAULT 1111111111,
  `ifsc` varchar(255) NOT NULL DEFAULT 'Not Addeed',
  `withdraw` int(255) NOT NULL,
  `refcode1` varchar(11) NOT NULL,
  `refcode2` varchar(11) NOT NULL,
  `name` varchar(211) NOT NULL,
  `upi` varchar(211) NOT NULL,
  `nickname` varchar(211) NOT NULL DEFAULT 'User',
  `bonus` int(211) NOT NULL,
  `r_ip` varchar(211) DEFAULT NULL,
  `bankname` varchar(211) NOT NULL,
  `state` varchar(211) NOT NULL,
  `city` varchar(211) NOT NULL,
  `address` varchar(511) NOT NULL,
  `mobile` varchar(211) NOT NULL,
  `email` varchar(211) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `ip` varchar(211) DEFAULT NULL,
  `paytm` varchar(211) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `refcode`, `usercode`, `created_at`, `balance`, `account`, `ifsc`, `withdraw`, `refcode1`, `refcode2`, `name`, `upi`, `nickname`, `bonus`, `r_ip`, `bankname`, `state`, `city`, `address`, `mobile`, `email`, `status`, `ip`, `paytm`) VALUES
(1, '1234567890', '123456', '', 'HO6GRZ', '2023-10-25 11:49:27', 150.18, 1111111111, 'Not Addeed', 0, '', '', '', '', 'User', 0, NULL, '', '', '', '', '', '', 0, '103.215.225.32', ''),
(7, '8355965199', '123456', 'HO6GRZ', '8946IVMK', '2023-10-25 11:51:34', 504.7, 1111111111, 'Not Addeed', 0, '', '', '', '', 'User', 0, '103.215.225.32', '', '', '', '', '', '', 0, '103.215.225.32', '');

-- --------------------------------------------------------

--
-- Table structure for table `verify`
--

CREATE TABLE `verify` (
  `id` int(11) NOT NULL,
  `username` bigint(255) NOT NULL,
  `otp` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `verify`
--

INSERT INTO `verify` (`id`, `username`, `otp`, `time`, `ip`) VALUES
(4, 8355965199, 56409, '2023-10-25 06:21:09', '');

-- --------------------------------------------------------

--
-- Table structure for table `vipbet`
--

CREATE TABLE `vipbet` (
  `TIME` datetime NOT NULL DEFAULT current_timestamp(),
  `id` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vipbetrec`
--

CREATE TABLE `vipbetrec` (
  `id` int(11) NOT NULL,
  `period` bigint(20) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `clo` tinytext NOT NULL,
  `num` varchar(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vipbetrec`
--

INSERT INTO `vipbetrec` (`id`, `period`, `ans`, `clo`, `num`, `time`) VALUES
(1, 20231026676, '269.89', 'redlion', '40561', '2023-10-25 11:48:27'),
(2, 20231026677, '118.37', 'yellowelephant', '46771', '2023-10-25 11:49:26'),
(3, 20231026678, '250.95', 'yellowlion', '47558', '2023-10-25 11:50:01'),
(4, 20231026679, '279.36', 'yellowlion', '43695', '2023-10-25 11:51:32'),
(5, 20231026680, '89.96', 'redelephant', '44996', '2023-10-25 11:52:32'),
(6, 20231026681, '80.49', 'greenelephant', '48392', '2023-10-25 11:53:27'),
(7, 20231026682, '4.73', 'greenking', '47737', '2023-10-25 11:54:27'),
(8, 20231026683, '89.96', 'redelephant', '40205', '2023-10-25 11:55:27');

-- --------------------------------------------------------

--
-- Table structure for table `vipbetting`
--

CREATE TABLE `vipbetting` (
  `id` int(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `period` varchar(255) NOT NULL,
  `ans` varchar(11) NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `res` varchar(255) NOT NULL DEFAULT 'wait',
  `fres` varchar(211) NOT NULL DEFAULT 'wait',
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vipperiod`
--

CREATE TABLE `vipperiod` (
  `id` int(11) NOT NULL DEFAULT 0,
  `period` bigint(20) NOT NULL,
  `nxt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vipperiod`
--

INSERT INTO `vipperiod` (`id`, `period`, `nxt`) VALUES
(1, 20231026684, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abbetrec`
--
ALTER TABLE `abbetrec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `abbetting`
--
ALTER TABLE `abbetting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `abperiod`
--
ALTER TABLE `abperiod`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apply`
--
ALTER TABLE `apply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beconebet`
--
ALTER TABLE `beconebet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beconebetrec`
--
ALTER TABLE `beconebetrec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beconebetting`
--
ALTER TABLE `beconebetting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beconeperiod`
--
ALTER TABLE `beconeperiod`
  ADD PRIMARY KEY (`period`);

--
-- Indexes for table `bet`
--
ALTER TABLE `bet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `betrec`
--
ALTER TABLE `betrec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `betting`
--
ALTER TABLE `betting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bonus`
--
ALTER TABLE `bonus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crashbetrecord`
--
ALTER TABLE `crashbetrecord`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crashgamerecord`
--
ALTER TABLE `crashgamerecord`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emredbet`
--
ALTER TABLE `emredbet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emredbetrec`
--
ALTER TABLE `emredbetrec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emredbetting`
--
ALTER TABLE `emredbetting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emredperiod`
--
ALTER TABLE `emredperiod`
  ADD PRIMARY KEY (`period`);

--
-- Indexes for table `gift`
--
ALTER TABLE `gift`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `giftrec`
--
ALTER TABLE `giftrec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `help`
--
ALTER TABLE `help`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otp`
--
ALTER TABLE `otp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `period`
--
ALTER TABLE `period`
  ADD PRIMARY KEY (`period`);

--
-- Indexes for table `recharge`
--
ALTER TABLE `recharge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `record`
--
ALTER TABLE `record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saprebet`
--
ALTER TABLE `saprebet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saprebetrec`
--
ALTER TABLE `saprebetrec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saprebetting`
--
ALTER TABLE `saprebetting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sapreperiod`
--
ALTER TABLE `sapreperiod`
  ADD PRIMARY KEY (`period`);

--
-- Indexes for table `signin`
--
ALTER TABLE `signin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `verify`
--
ALTER TABLE `verify`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vipbet`
--
ALTER TABLE `vipbet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vipbetrec`
--
ALTER TABLE `vipbetrec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vipbetting`
--
ALTER TABLE `vipbetting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vipperiod`
--
ALTER TABLE `vipperiod`
  ADD PRIMARY KEY (`period`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abbetrec`
--
ALTER TABLE `abbetrec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `abbetting`
--
ALTER TABLE `abbetting`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(211) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `apply`
--
ALTER TABLE `apply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `beconebetrec`
--
ALTER TABLE `beconebetrec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `beconebetting`
--
ALTER TABLE `beconebetting`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `betrec`
--
ALTER TABLE `betrec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `betting`
--
ALTER TABLE `betting`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bonus`
--
ALTER TABLE `bonus`
  MODIFY `id` int(211) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `crashbetrecord`
--
ALTER TABLE `crashbetrecord`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `crashgamerecord`
--
ALTER TABLE `crashgamerecord`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emredbetrec`
--
ALTER TABLE `emredbetrec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `emredbetting`
--
ALTER TABLE `emredbetting`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gift`
--
ALTER TABLE `gift`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `giftrec`
--
ALTER TABLE `giftrec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `help`
--
ALTER TABLE `help`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `id` int(211) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `otp`
--
ALTER TABLE `otp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `recharge`
--
ALTER TABLE `recharge`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `record`
--
ALTER TABLE `record`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saprebetrec`
--
ALTER TABLE `saprebetrec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `saprebetting`
--
ALTER TABLE `saprebetting`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `signin`
--
ALTER TABLE `signin`
  MODIFY `id` int(211) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `verify`
--
ALTER TABLE `verify`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vipbetrec`
--
ALTER TABLE `vipbetrec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vipbetting`
--
ALTER TABLE `vipbetting`
  MODIFY `id` int(225) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
