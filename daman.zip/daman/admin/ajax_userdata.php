<?php
include ("include/connection.php");
if($_POST['id'])
{

$id=$_POST['id'];

$sql=mysqli_query($con,"select * from `tbl_user` where `id` ='".$id."'");
$rows=mysqli_num_rows($sql);
$selectwallet=mysqli_query($con,"select * from `tbl_wallet` where `userid`='".$userid."'");
$walletResult=mysqli_fetch_array($selectwallet);
if($rows!=''){
?>
<body>
<div class="col-xs-12 text-center">
<h4>User Details</h4>
<table class="table table-bordered table-striped text-center">
    <tr>
<th>ID (Auto Login)</th>
<th>Phone</th>
<th>Referid</th>
<th>Referby</th>
<th>Wallet</th>
<th>Create Date</th>
    </tr>
<?php
while($row=mysqli_fetch_array($sql))
{
$id=$row['id'];
?>
<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['mobile']; ?></td>
    <td><?php echo $row['owncode']; ?></td>
    <td><?php echo $row['code']; ?></td>
     <!--<td><?php echo wallet($con,'amount',$row["0"]);?></td>-->
     <td><?php echo number_format(wallet($con,'amount',$row["0"]),2);?>&nbsp;<a href="javascript:void(0);" onClick="edit(<?php echo $row['0']; ?>,<?php echo @$row["mobile"]; ?>,<?php echo wallet($con,'amount',$row["0"]);?>)" class="text-aqua" title="Delete"><i class="fa fa-edit"></i></a>              
    <td><?php echo $row['createdate']; ?></td>  
    </tr>
<?php }?>
</table>
  
           <a href="user_game_history.php?user=<?php echo $id?>"  class="btn btn-info" style="font-size:16px; margin-top: 10px;" data-toggle="tooltip" title="Edit">Play History</a>    
               <!--<a href="javascript:void(0);" onClick="delete_row(<?php echo $row['id']; ?>)" class="update-person" style="color:#f56954; font-size:16px;" title="Delete"><i class="fa fa-trash"></i></a> -->
        <?php 
    if($row['status']==1){
    ?>
    
      <?php } else if($row['status']==0){?>
      
       <?php }?>
      <a href="edit_user_info.php?user=<?php echo $id?>"  class="btn btn-warning" style="font-size:16px; margin-top: 10px;" data-toggle="tooltip" title="Edit">Edit</a>
	  <a href="usercode.php?code=<?php echo $owncode?>"  class="btn btn-success" style="font-size:16px; margin-top: 10px;" data-toggle="tooltip" title="Edit">View Team</a> 
	  <a href="auth.php?user=<?php echo $id?>"  class="btn btn-success" style="font-size:16px; margin-top: 10px;" data-toggle="tooltip" title="Edit">Login as user</a> 
      
      
</div>
 <?php 
// }else{
// $id='0';
// $data='Nothing found...';
// ?>
<!--// <div class="col-xs-12 text-center">-->
<!--// <h4>Reward History</h4>-->
<!--<table class="table table-bordered table-striped text center">-->
<!--    <tr><td colspan="2"><?php echo $data;?></td></tr>-->
<!--</table>-->
</div>
<?php
}
}
?>

  <div id="excel" class="modal fade" role="dialog">
  <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="chn">Change Amount<br>
<small id="mob"></small></h4>
              </div>
  <form name="type" id="type" enctype="multipart/form-data" action="#" method="post">
              <div class="modal-body">
              
              <div class="form-group ">
                  <label for="add_item">Amount</label>  
   <input class="form-control" id="amount" name="amount" type="text" value="" onkeypress="return isNumber(event)" required>
    <input class="form-control" id="editid" name="editid"  type="hidden">
    <i id="error"></i>
                </div>
            			
              </div>
              <div class="modal-footer">
                
  <button type="submit" class="btn btn-danger" id="add_role">Save</button>
              </div>
              </form>
            </div>
            <!-- /.modal-content -->
          </div>
         
</div>

<script type="text/javascript">

function edit(id,mob,balance) {
$('#excel').modal({backdrop: 'static', keyboard: false})   
 $('#excel').modal('show');
 document.getElementById('mob').innerHTML = 'Mobile: '+mob;
 document.getElementById('amount').value = balance;
 document.getElementById('editid').value = id;
}

$(document).ready(function () {
		$("#type").on('submit',(function(e) {
		e.preventDefault();
var quantity = $('input#quantity').val();
if ((quantity)== "") {
            $("input#quantity").focus();
			$('#quantity').css({'border-color': '#f00'});
            return false;}
			
			
		$.ajax({
			type: "POST", 
			url: "updatewalletNow.php",              
			data: new FormData(this), 
			contentType: false,       
			cache: false,             
			processData:false,       

			success: function(html)   
			{ //alert(html);
			if (html == 1) {
			alert("Amount update successfully...");
        window.location.href="recharge.php";

            $("#type")[0].reset();
			 $('#excel').modal('hide');
			  window.location ='';
			}
			
			else if(html==0)
			{ alert("Some Technical Error....");		
				}
			
			}
		});
	
	}));
	
	
	
});
</script>
</body>