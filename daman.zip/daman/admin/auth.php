<?php      
ob_start();
session_start();
if($_SESSION['userid']=="")
{
	header("location:index.php?msg1=notauthorized");
	exit();
} else
if(isset($_GET['userid'])){
    
    $_SESSION['frontuserid']=$_GET['userid'];
    
 header("Location: /");
exit();
}
?>