<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (DoughouzForest)
// | @author_url 1: http://www.askmescript.com
// | @author_url 2: http://codecanyon.net/user/doughouzforest
// | @author_email: wowondersocial@gmail.com
// +------------------------------------------------------------------------+
// | AskMe - The Ultimate PHP Question & Answers Platform
// | Copyright (c) 2019 AskMe. All rights reserved.
// +------------------------------------------------------------------------+
header('Location: ./install');

exit();
// MySQL Hostname
$sql_db_host = "localhost";
// MySQL Database User
$sql_db_user = "root";
// MySQL Database Password
$sql_db_pass = "";
// MySQL Database Name
$sql_db_name = "askme";

// Site URL
$site_url = "http://localhost/ask"; // e.g (http://example.com)

$app = "AskMe";

// Purchase code
$purchase_code = "e4be513e-19de-4155-bcc7-4dcd9c462d57"; // Your purchase code, don't give it to anyone.
?>