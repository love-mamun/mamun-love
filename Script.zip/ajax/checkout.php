<?php
if (empty($_POST['card_number']) || empty($_POST['card_cvc']) || empty($_POST['card_month']) || empty($_POST['card_year']) || empty($_POST['token']) || empty($_POST['card_name']) || empty($_POST['card_address']) || empty($_POST['card_city']) || empty($_POST['card_state']) || empty($_POST['card_zip']) || empty($_POST['card_country']) || empty($_POST['card_email']) || empty($_POST['card_phone'])) {
    $data = array(
        'status' => 400,
        'error' => __('please_check_details')
    );
} else {
    require_once 'assets/import/2checkout/Twocheckout.php';
    Twocheckout::privateKey($ask->config->checkout_private_key);
    Twocheckout::sellerId($ask->config->checkout_seller_id);
    if ($ask->config->checkout_mode == 'sandbox') {
        Twocheckout::sandbox(true);
    } else {
        Twocheckout::sandbox(false);
    }
    try {
        $amount1 = $_POST['amount'];
        $charge  = Twocheckout_Charge::auth(array(
            "merchantOrderId" => "123",
            "token" => $_POST['token'],
            "currency" => $ask->config->2checkout_currency,
            "total" => $amount1,
            "billingAddr" => array(
                "name" => $_POST['card_name'],
                "addrLine1" => $_POST['card_address'],
                "city" => $_POST['card_city'],
                "state" => $_POST['card_state'],
                "zipCode" => $_POST['card_zip'],
                "country" => $ask->countries_name[$_POST['card_country']],
                "email" => $_POST['card_email'],
                "phoneNumber" => $_POST['card_phone']
            )
        ));
        if ($charge['response']['responseCode'] == 'APPROVED') {
        	$amount = Secure($_POST['amount']);
        	$updateUser = $db->where('id', $user->id)->update(T_USERS, ['wallet' => $db->inc($amount)]);

	        if ($updateUser) {
	            CreatePayment(array(
                    'user_id'   => $ask->user->id,
                    'amount'    => $amount,
                    'type'      => 'WALLET',
                    'pro_plan'  => 0,
                    'info'      => 'Replenish My Balance',
                    'via'       => '2checkout'
                ));
                $data = array(
	                'status' => 200,
	                'location' => UrlLink('wallet')
	            );
	            header("Content-type: application/json");
	            echo json_encode($data);
	            exit();
	        }  
           else {
	            $data = array(
	                'status' => 400,
	                'error' => __('2checkout_declined')
	            );
	            header("Content-type: application/json");
	            echo json_encode($data);
	            exit();
	        }
        } else {
            $data = array(
                'status' => 400,
                'error' => __('2checkout_declined')
            );
            header("Content-type: application/json");
            echo json_encode($data);
            exit();
        }
    }
    catch (Twocheckout_Error $e) {
        $data = array(
            'status' => 400,
            'error' => $e->getMessage()
        );
        header("Content-type: application/json");
        echo json_encode($data);
        exit();
    }
}