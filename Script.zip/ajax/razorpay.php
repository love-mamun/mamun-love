<?php
if ($first == 'wallet') {
	if (!empty($_POST['payment_type']) && $_POST['payment_type'] == 'wallet' && !empty($_POST['payment_id']) && !empty($_POST['order_id']) && !empty($_POST['merchant_amount']) && !empty($_POST['currency'])) {

		$payment_id = Secure($_POST['payment_id']);
		$price    = Secure($_POST['merchant_amount']);
		$currency_code = "INR";
	    $check = array(
		    'amount' => $price,
		    'currency' => $currency_code,
		);
		$json = CheckRazorpayPayment($payment_id,$check);
		if (!empty($json) && empty($json->error_code)) {
			$amount = $price / 100;
			$updateUser = $db->where('id', $ask->user->id)->update(T_USERS, ['wallet' => $db->inc($amount)]);
			if ($updateUser) {
				CreatePayment(array(
		            'user_id'   => $ask->user->id,
		            'amount'    => $amount,
		            'type'      => 'WALLET',
		            'pro_plan'  => 0,
		            'info'      => 'Replenish My Balance',
		            'via'       => 'razorpay'
		        ));
		        $data['url'] = UrlLink('wallet');
			}
			else{
				$data['message'] = __('something_went_wrong__please_try_again_later.');
			}
		}
		else{
	    	$data['message'] = $json->error_code . ':' . $json->error_description;
	    }
	}
	else{
		$data['message'] = __('please_check_details');
	}
	header("Content-type: application/json");
    echo json_encode($data);
    exit();
}