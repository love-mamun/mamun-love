<?php
$types = array(
        'week',
        'year',
        'month',
        'life-time',
        'wallet',
        'fund'
    );
if ($first == 'get_url') {
	if (!empty($_POST['payment_type']) && in_array($_POST['payment_type'], $types)) {
		$type = $_POST['payment_type'];
		$price    = 0;
	    if ($type == 'wallet') {
	    	if (!empty($_POST['amount']) && is_numeric($_POST['amount']) && $_POST['amount'] > 0) {
	    		$price = $_POST['amount'];
	    		$callback_url = $ask->config->site_url.'/aj/paysera/wallet?amount='.$price;
	    	}
	    	else{
	    		$data['status'] = 400;
				$data['message'] = __('please_check_details');
				header("Content-type: application/json");
			    echo json_encode($data);
			    exit();
	    	}
	    }

	    require_once('assets/import/Paysera.php');

	    $request = WebToPay::redirectToPayment(array(
		    'projectid'     => $ask->config->paysera_project_id,
		    'sign_password' => $ask->config->paysera_sign_password,
		    'orderid'       => rand(111111,999999),
		    'amount'        => $price,
		    'currency'      => $ask->config->ads_currency,
		    'country'       => 'LT',
		    'accepturl'     => $callback_url,
		    'cancelurl'     => UrlLink('404'),
		    'callbackurl'   => UrlLink('404'),
		    'test'          => $ask->config->paysera_mode,
		));
		$data = array('status' => 200,
	                  'url' => $request);
	}
	header("Content-type: application/json");
    echo json_encode($data);
    exit();

}

if ($first == 'wallet') {
	require_once('assets/import/Paysera.php');
	try {
        $response = WebToPay::checkResponse($_GET, array(
            'projectid'     => $ask->config->paysera_project_id,
            'sign_password' => $ask->config->paysera_sign_password,
        ));
 
        // if ($response['test'] !== '0') {
        //     throw new Exception('Testing, real payment was not made');
        // }
        if ($response['type'] !== 'macro') {
        	header("Location: " . UrlLink('404'));
            exit();
            //throw new Exception('Only macro payment callbacks are accepted');
        }
        $amount = $response['amount'];
        $currency = $response['currency'];

        if ($currency != $ask->config->ads_currency) {
        	header("Location: " . UrlLink('404'));
            exit();
        }
        else{
        	$amount = $amount;
			$updateUser = $db->where('id', $ask->user->id)->update(T_USERS, ['wallet' => $db->inc($amount)]);
			if ($updateUser) {
				CreatePayment(array(
		            'user_id'   => $ask->user->id,
		            'amount'    => $amount,
		            'type'      => 'WALLET',
		            'pro_plan'  => 0,
		            'info'      => 'Replenish My Balance',
		            'via'       => 'paystack'
		        ));
		        $data['url'] = UrlLink('wallet');
			}
			else{
				header("Location: " . UrlLink('404'));
		        exit();
			}
        }
	} catch (Exception $e) {
	    header("Location: " . UrlLink('404'));
        exit();
	}
}