<?php
if ($first == 'initialize') {
	$types = array('wallet');

	if (!empty($_POST['payment_type']) && in_array($_POST['payment_type'], $types) && !empty($_POST['email']) && filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
		$type = $_POST['payment_type'];
		$price    = 0;

	    if ($type == 'wallet') {
	    	if (!empty($_POST['amount']) && is_numeric($_POST['amount']) && $_POST['amount'] > 0) {
	    		$price = $_POST['amount'];
	    		$callback_url = $ask->config->site_url.'/aj/paystack/wallet?amount='.$price;
	    	}
	    	else{
	    		$data['status'] = 400;
				$data['message'] = __('please_check_details');
				header("Content-type: application/json");
			    echo json_encode($data);
			    exit();
	    	}
	    }

	    $result = array();
	    $reference = uniqid();

		//Set other parameters as keys in the $postdata array
		$postdata =  array('email' => $_POST['email'], 'amount' => $price,"reference" => $reference,'callback_url' => $callback_url);
		$url = "https://api.paystack.co/transaction/initialize";

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postdata));  //Post Fields
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$headers = [
		  'Authorization: Bearer '.$ask->config->paystack_secret_key,
		  'Content-Type: application/json',

		];
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$request = curl_exec ($ch);

		curl_close ($ch);

		if ($request) {
		    $result = json_decode($request, true);
		    if (!empty($result)) {
				 if (!empty($result['status']) && $result['status'] == 1 && !empty($result['data']) && !empty($result['data']['authorization_url']) && !empty($result['data']['access_code'])) {
				 	$db->where('id',$ask->user->id)->update(T_USERS,array('paystack_ref' => $reference));
				  	$data['status'] = 200;
				  	$data['url'] = $result['data']['authorization_url'];
				}
				else{
					$data['status'] = 400;
			        $data['message'] = $result['message'];
				}
			}
			else{
				$data['status'] = 400;
			    $data['message'] = __('something_went_wrong__please_try_again_later.');
			}
		}
		else{
			$data['status'] = 400;
			$data['message'] = __('something_went_wrong__please_try_again_later.');
		}
	}
	else{
		$data['status'] = 400;
		$data['message'] = __('something_went_wrong__please_try_again_later.');
	}
	header("Content-type: application/json");
    echo json_encode($data);
    exit();
}
if ($first == 'wallet') {
	$payment  = CheckPaystackPayment($_GET['reference']);
	if ($payment) {
		$amount = Secure($_GET['amount']) / 100;
		$updateUser = $db->where('id', $ask->user->id)->update(T_USERS, ['wallet' => $db->inc($amount)]);
		if ($updateUser) {
			CreatePayment(array(
	            'user_id'   => $ask->user->id,
	            'amount'    => $amount,
	            'type'      => 'WALLET',
	            'pro_plan'  => 0,
	            'info'      => 'Replenish My Balance',
	            'via'       => 'paystack'
	        ));
	        header("Location: " . UrlLink('wallet'));
			exit();
		}
		else{
			header("Location: " . UrlLink('404'));
		    exit();
		}
    } else {
        header("Location: " . UrlLink('404'));
        exit();
    }
}