<?php
if (IS_LOGGED == false || empty($ask->config->paypal_id) || empty($ask->config->paypal_secret)) {
    $data = array('status' => 400, 'error' => 'Not logged in');
    echo json_encode($data);
    exit();
}
if ($first == 'get_link') {
	if (!empty($_GET['payment_type']) && in_array($_GET['payment_type'], array('wallet'))) {
		$url = '';
		if ($_GET['payment_type'] == 'wallet' && !empty($_GET['amount']) && is_numeric($_GET['amount']) && $_GET['amount'] > 0) {
			$url = ReplenishWallet(Secure($_GET['amount']));
		}
		if (!empty($url) && !empty($url['type']) && $url['type'] == 'SUCCESS') {
			$data = array(
	            'status' => 200,
	            'url' => $url['url']
	        );
		}
		else{
			$data = array(
	            'status' => 400,
	            'message' => $url['details']
	        );
		}
	}
	else{
		$data = array(
            'status' => 400,
            'message' => __('something_went_wrong__please_try_again_later.')
        );
	}
}