<?php
if (IS_LOGGED == false || $ask->config->stripe_payment != 'on') {
    $data = array('status' => 400, 'error' => 'Not logged in');
    echo json_encode($data);
    exit();
}
require_once('assets/import/stripe-php-3.20.0/autoload.php');
$stripe = array(
  "secret_key"      =>  $ask->config->stripe_secret,
  "publishable_key" =>  $ask->config->stripe_id
);

\Stripe\Stripe::setApiKey($stripe['secret_key']);

if ($first == 'session') {
	if (!empty($_POST['type']) && in_array($_POST['type'], array('wallet'))) {
		$amount = 0;
		if ($_POST['type'] == 'wallet' && !empty($_POST['amount']) && is_numeric($_POST['amount']) && $_POST['amount'] > 0) {
			$amount = $_POST['amount'] * 100;
		}
		$payment_method_types = array('card');
		$domain_url = $ask->config->site_url.'/aj/stripe';

		try {
			$checkout_session = \Stripe\Checkout\Session::create([
			    'payment_method_types' => [implode(',', $payment_method_types)],
			    'line_items' => [[
			      'price_data' => [
			        'currency' => $ask->config->stripe_currency,
			        'product_data' => [
			          'name' => $_POST['type'],
			        ],
			        'unit_amount' => $amount,
			      ],
			      'quantity' => 1,
			    ]],
			    'mode' => 'payment',
			    'success_url' => $domain_url . '/success?result_type='.$_POST['type'],
			    'cancel_url' => $domain_url . '/cancel?result_type='.$_POST['type'],
		    ]);
		    if (!empty($checkout_session) && !empty($checkout_session['id'])) {
		    	$db->where('id',$ask->user->id)->update(T_USERS,array('StripeSessionId' => $checkout_session['id']));
		    	$data = array(
	                'status' => 200,
	                'sessionId' => $checkout_session['id']
	            );
		    }
		    else{
		    	$data = array(
	                'status' => 400,
	                'message' => __('something_went_wrong__please_try_again_later.')
	            );
		    }
		}
		catch (Exception $e) {
			$data = array(
                'status' => 400,
                'message' => $e->getMessage()
            );
		}
        header("Content-type: application/json");
        echo json_encode($data);
        exit();
	}
}
if ($first == 'success') {
	if (!empty($_GET['result_type']) && in_array($_GET['result_type'], array('wallet'))) {
		if (!empty($ask->user->StripeSessionId) && !empty($_GET['result_type']) && in_array($_GET['result_type'], array('wallet'))) {
			try {
				$db->where('id',$ask->user->id)->update(T_USERS,array('StripeSessionId' => ''));
				$checkout_session = \Stripe\Checkout\Session::retrieve($ask->user->StripeSessionId);
				if ($checkout_session->payment_status == 'paid') {
					$amount = ($checkout_session->amount_total / 100);
					if ($_GET['result_type'] == 'wallet') {
						$updateUser = $db->where('id', $user->id)->update(T_USERS, ['wallet' => $db->inc($amount)]);

				        if ($updateUser) {
				            CreatePayment(array(
			                    'user_id'   => $ask->user->id,
			                    'amount'    => $amount,
			                    'type'      => 'WALLET',
			                    'pro_plan'  => 0,
			                    'info'      => 'Replenish My Balance',
			                    'via'       => 'Stripe'
			                ));
			                header("Location: " . UrlLink('wallet'));
                            exit();
				        }  
			           else {
				            header("Location: " . UrlLink('404'));
		                    exit();
				        }
					}
				}
				else{
					header("Location: " . UrlLink('404'));
                    exit();
				}
				
			} catch (Exception $e) {
				header("Location: " . UrlLink('404'));
                exit();
			}
		}
		header("Location: " . UrlLink('404'));
        exit();
	}
}
if ($first == 'cancel') {
	$db->where('id',$ask->user->id)->update(T_USERS,array('StripeSessionId' => ''));
	header("Location: " . UrlLink('404'));
    exit();
}