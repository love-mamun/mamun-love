<?php
echo json_encode(array('status' => 200, 'data'=>$config));
exit();
