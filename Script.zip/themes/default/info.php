<?php
$themeName = 'default';
$themeVirsion = '1.0.0';
$themeAuthor = 'askme';
$themeAuthorUrl = 'https://www.askme.com';
$themeImg = $themeName . '/img/icon.png';